import React, { useEffect, useState } from 'react';
import { View, StyleSheet, FlatList } from 'react-native';
import { List, Avatar, ActivityIndicator, Searchbar, FAB } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import api from '../services/api';

interface Dealership {
  id: string;
  name: string;
  address: string;
  city: string;
  phone: string;
  rating: number;
  imageUrl?: string;
}

type NavigationProp = StackNavigationProp<RootStackParamList, 'MainTabs'>;

export default function DealershipListScreen() {
  const navigation = useNavigation<NavigationProp>();
  const [dealerships, setDealerships] = useState<Dealership[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchDealerships();
  }, []);

  const fetchDealerships = async () => {
    try {
      // Replace with your actual API endpoint
      // const response = await api.get('/dealerships');
      // setDealerships(response.data);
      
      // Simulated data
      setDealerships([
        { id: '1', name: 'AutoMax Downtown', address: '123 Main St', city: 'New York', phone: '(555) 123-4567', rating: 4.5 },
        { id: '2', name: 'Premier Motors', address: '456 Oak Ave', city: 'Los Angeles', phone: '(555) 987-6543', rating: 4.8 },
        { id: '3', name: 'City Cars Hub', address: '789 Pine Rd', city: 'Chicago', phone: '(555) 456-7890', rating: 4.2 },
        { id: '4', name: 'Speedway Auto', address: '321 Elm St', city: 'Houston', phone: '(555) 234-5678', rating: 4.6 },
        { id: '5', name: 'Grand Automotive', address: '654 Maple Dr', city: 'Phoenix', phone: '(555) 876-5432', rating: 4.3 },
      ]);
    } catch (error) {
      console.error('Error fetching dealerships:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredDealerships = dealerships.filter(d =>
    d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.city.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Searchbar
        placeholder="Search dealerships..."
        onChangeText={setSearchQuery}
        value={searchQuery}
        style={styles.searchbar}
      />
      <FlatList
        data={filteredDealerships}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <List.Item
            title={item.name}
            description={`${item.address}, ${item.city}\n⭐ ${item.rating} | 📞 ${item.phone}`}
            left={props => <Avatar.Icon {...props} icon="car" />}
            onPress={() => navigation.navigate('DealershipDetail', { dealershipId: item.id })}
          />
        )}
      />
      <FAB
        style={styles.fab}
        icon="map"
        label="View on Map"
        onPress={() => navigation.navigate('MainTabs', { screen: 'Map' } as any)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  searchbar: {
    margin: 10,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
  },
});
