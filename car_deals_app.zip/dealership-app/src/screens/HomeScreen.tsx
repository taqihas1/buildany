import React, { useEffect, useState } from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { Card, Title, Paragraph, Button, ActivityIndicator, Searchbar } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import api from '../services/api';

interface Dealership {
  id: string;
  name: string;
  address: string;
  city: string;
  phone: string;
  rating: number;
}

type NavigationProp = StackNavigationProp<RootStackParamList, 'MainTabs'>;

export default function HomeScreen() {
  const navigation = useNavigation<NavigationProp>();
  const [dealerships, setDealerships] = useState<Dealership[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchDealerships();
  }, []);

  const fetchDealerships = async () => {
    try {
      // Replace with your actual API endpoint
      // const response = await api.get('/dealerships');
      // setDealerships(response.data);
      
      // Simulated data for demo
      setDealerships([
        { id: '1', name: 'AutoMax Downtown', address: '123 Main St', city: 'New York', phone: '(555) 123-4567', rating: 4.5 },
        { id: '2', name: 'Premier Motors', address: '456 Oak Ave', city: 'Los Angeles', phone: '(555) 987-6543', rating: 4.8 },
        { id: '3', name: 'City Cars Hub', address: '789 Pine Rd', city: 'Chicago', phone: '(555) 456-7890', rating: 4.2 },
      ]);
    } catch (error) {
      console.error('Error fetching dealerships:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredDealerships = dealerships.filter(d =>
    d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.city.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Searchbar
        placeholder="Search dealerships..."
        onChangeText={setSearchQuery}
        value={searchQuery}
        style={styles.searchbar}
      />
      <FlatList
        data={filteredDealerships}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Card style={styles.card}>
            <Card.Content>
              <Title>{item.name}</Title>
              <Paragraph>{item.address}, {item.city}</Paragraph>
              <Paragraph>📞 {item.phone}</Paragraph>
              <Paragraph>⭐ {item.rating} / 5</Paragraph>
            </Card.Content>
            <Card.Actions>
              <Button onPress={() => navigation.navigate('DealershipDetail', { dealershipId: item.id })}>
                View Details
              </Button>
            </Card.Actions>
          </Card>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: '#f5f5f5',
  },
  searchbar: {
    marginBottom: 10,
  },
  card: {
    marginBottom: 10,
    elevation: 2,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
