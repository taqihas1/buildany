import React, { useEffect, useState } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Card, Title, Paragraph, Button, Chip, ActivityIndicator, Divider } from 'react-native-paper';
import { RouteProp, useRoute } from '@react-navigation/native';
import { RootStackParamList } from '../navigation/AppNavigator';
import api from '../services/api';

type DealershipDetailRouteProp = RouteProp<RootStackParamList, 'DealershipDetail'>;

interface Dealership {
  id: string;
  name: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
  email: string;
  rating: number;
  hours: string;
  services: string[];
}

export default function DealershipDetailScreen() {
  const route = useRoute<DealershipDetailRouteProp>();
  const { dealershipId } = route.params;
  const [dealership, setDealership] = useState<Dealership | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDealershipDetails();
  }, [dealershipId]);

  const fetchDealershipDetails = async () => {
    try {
      // Replace with your actual API endpoint
      // const response = await api.get(`/dealerships/${dealershipId}`);
      // setDealership(response.data);
      
      // Simulated data
      setDealership({
        id: dealershipId,
        name: 'AutoMax Downtown',
        address: '123 Main Street',
        city: 'New York',
        state: 'NY',
        zipCode: '10001',
        phone: '(555) 123-4567',
        email: 'contact@automax.com',
        rating: 4.5,
        hours: 'Mon-Fri: 9AM-8PM\nSat: 10AM-6PM\nSun: 12PM-5PM',
        services: ['Sales', 'Service', 'Parts', 'Financing', 'Test Drives'],
      });
    } catch (error) {
      console.error('Error fetching dealership details:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  if (!dealership) {
    return (
      <View style={styles.center}>
        <Paragraph>Dealership not found</Paragraph>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Card style={styles.card}>
        <Card.Content>
          <Title>{dealership.name}</Title>
          <Paragraph style={styles.rating}>⭐ {dealership.rating} / 5</Paragraph>
          
          <Divider style={styles.divider} />
          
          <Title style={styles.sectionTitle}>Contact Information</Title>
          <Paragraph>📍 {dealership.address}</Paragraph>
          <Paragraph>   {dealership.city}, {dealership.state} {dealership.zipCode}</Paragraph>
          <Paragraph>📞 {dealership.phone}</Paragraph>
          <Paragraph>✉️ {dealership.email}</Paragraph>
          
          <Divider style={styles.divider} />
          
          <Title style={styles.sectionTitle}>Business Hours</Title>
          <Paragraph>{dealership.hours}</Paragraph>
          
          <Divider style={styles.divider} />
          
          <Title style={styles.sectionTitle}>Services</Title>
          <View style={styles.chipContainer}>
            {dealership.services.map((service, index) => (
              <Chip key={index} style={styles.chip}>{service}</Chip>
            ))}
          </View>
        </Card.Content>
        <Card.Actions style={styles.actions}>
          <Button mode="contained" onPress={() => console.log('Call')}>
            Call Now
          </Button>
          <Button mode="outlined" onPress={() => console.log('Directions')}>
            Get Directions
          </Button>
        </Card.Actions>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  card: {
    margin: 10,
    elevation: 2,
  },
  rating: {
    fontSize: 18,
    color: '#6200ee',
    marginTop: 5,
  },
  sectionTitle: {
    fontSize: 16,
    marginTop: 15,
    marginBottom: 5,
  },
  divider: {
    marginVertical: 10,
  },
  chipContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 5,
  },
  chip: {
    margin: 4,
  },
  actions: {
    flexDirection: 'column',
    gap: 10,
    padding: 15,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
