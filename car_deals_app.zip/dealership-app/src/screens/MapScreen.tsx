import React from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import MapView, { Marker, Callout } from 'react-native-maps';
import { Title, Paragraph, Card } from 'react-native-paper';

const { width, height } = Dimensions.get('window');

interface DealershipLocation {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  address: string;
  phone: string;
}

const DEALERSHIPS: DealershipLocation[] = [
  {
    id: '1',
    name: 'AutoMax Downtown',
    latitude: 40.7128,
    longitude: -74.0060,
    address: '123 Main St, New York, NY',
    phone: '(555) 123-4567',
  },
  {
    id: '2',
    name: 'Premier Motors',
    latitude: 34.0522,
    longitude: -118.2437,
    address: '456 Oak Ave, Los Angeles, CA',
    phone: '(555) 987-6543',
  },
  {
    id: '3',
    name: 'City Cars Hub',
    latitude: 41.8781,
    longitude: -87.6298,
    address: '789 Pine Rd, Chicago, IL',
    phone: '(555) 456-7890',
  },
];

export default function MapScreen() {
  return (
    <View style={styles.container}>
      <MapView
        style={styles.map}
        initialRegion={{
          latitude: 39.8283,
          longitude: -98.5795,
          latitudeDelta: 40,
          longitudeDelta: 40,
        }}
      >
        {DEALERSHIPS.map((dealership) => (
          <Marker
            key={dealership.id}
            coordinate={{
              latitude: dealership.latitude,
              longitude: dealership.longitude,
            }}
            title={dealership.name}
            description={dealership.address}
          >
            <Callout>
              <Card style={styles.calloutCard}>
                <Card.Content>
                  <Title>{dealership.name}</Title>
                  <Paragraph>{dealership.address}</Paragraph>
                  <Paragraph>📞 {dealership.phone}</Paragraph>
                </Card.Content>
              </Card>
            </Callout>
          </Marker>
        ))}
      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    width: width,
    height: height,
  },
  calloutCard: {
    width: 250,
    padding: 5,
  },
});
