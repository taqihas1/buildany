import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import MainTabNavigator from './MainTabNavigator';
import DealershipDetailScreen from '../screens/DealershipDetailScreen';

export type RootStackParamList = {
  MainTabs: undefined;
  DealershipDetail: { dealershipId: string };
};

const Stack = createStackNavigator<RootStackParamList>();

export default function AppNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="MainTabs" component={MainTabNavigator} />
      <Stack.Screen 
        name="DealershipDetail" 
        component={DealershipDetailScreen}
        options={{ headerShown: true, title: 'Dealership Details' }}
      />
    </Stack.Navigator>
  );
}
