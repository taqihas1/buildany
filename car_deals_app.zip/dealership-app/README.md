# Dealership App

A cross-platform mobile application built with React Native + Expo for finding and exploring car dealerships.

## Tech Stack

| Technology | Version | Purpose |
|------------|---------|---------|
| React Native | 0.74 | Core framework |
| Expo SDK | 51 | Development & build tooling |
| TypeScript | 5.1 | Type safety |
| React Navigation v6 | 6.x | Stack + Bottom Tab navigation |
| React Native Paper | 5.12 | Material Design UI components |
| React Native Maps | 1.18 | Interactive dealership location maps |
| Axios | 1.7 | API integration |
| @expo/vector-icons | 14.0 | Icon library |

## Project Structure

```
dealership-app/
├── App.tsx                  # App entry point with PaperProvider + NavigationContainer
├── src/
│   ├── navigation/
│   │   ├── AppNavigator.tsx         # Root Stack Navigator
│   │   └── MainTabNavigator.tsx       # Bottom Tabs (Home, Map, Dealerships, Settings)
│   ├── screens/
│   │   ├── HomeScreen.tsx           # Dashboard with search + featured dealerships
│   │   ├── MapScreen.tsx            # Full-screen map with dealership pins
│   │   ├── DealershipListScreen.tsx # List view of all dealerships
│   │   ├── DealershipDetailScreen.tsx # Detail view with contact info, hours, services
│   │   └── SettingsScreen.tsx       # User preferences & app settings
│   └── services/
│       └── api.ts                   # Axios instance + API helper functions
├── assets/                  # Images, fonts, etc.
└── package.json
```

## Features

- 🔍 **Search** - Find dealerships by name or city
- 🗺️ **Interactive Map** - View all dealership locations with callout details
- 📋 **Dealership List** - Browse all dealerships with ratings and contact info
- 📄 **Detail View** - Full dealership info: address, hours, services, contact buttons
- ⚙️ **Settings** - Notifications, location services, dark mode toggle
- 📱 **Material Design** - Clean, modern UI with React Native Paper

## Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn
- Expo Go app (iOS/Android) for testing on physical devices

### Installation

```bash
cd dealership-app
npm install
```

### Running the App

```bash
# Start the development server
npm start

# Run on Android
npm run android

# Run on iOS (macOS only)
npm run ios

# Run on Web
npm run web
```

### API Configuration

Update the API base URL in `src/services/api.ts`:

```typescript
const API_BASE_URL = 'https://your-api-domain.com/api';
```

Replace the simulated data in screens with actual API calls using the provided `dealershipApi` helpers:
- `dealershipApi.getAll()` - Fetch all dealerships
- `dealershipApi.getById(id)` - Fetch single dealership
- `dealershipApi.getNearby(lat, lng, radius)` - Find nearby dealerships
- `dealershipApi.search(query)` - Search dealerships

## Navigation Flow

```
App (PaperProvider + NavigationContainer)
└── Stack Navigator
    ├── MainTabs (Bottom Tabs)
    │   ├── Home Tab (Dashboard)
    │   ├── Map Tab (Dealership Map)
    │   ├── Dealerships Tab (List View)
    │   └── Settings Tab (Preferences)
    └── DealershipDetail (Stack Screen)
```

## Customization

### Adding Real API Data
Replace simulated data arrays in each screen with actual `api.get()` calls:

```typescript
const response = await api.get('/dealerships');
setDealerships(response.data);
```

### Theming
Modify the PaperProvider theme in `App.tsx`:

```typescript
import { DefaultTheme, MD3DarkTheme } from 'react-native-paper';

const customTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: '#your-brand-color',
  },
};
```

### Map Configuration
Add your Google Maps API key for Android/iOS in `app.json`:

```json
{
  "android": {
    "config": {
      "googleMaps": {
        "apiKey": "your-android-api-key"
      }
    }
  },
  "ios": {
    "config": {
      "googleMapsApiKey": "your-ios-api-key"
    }
  }
}
```

## Build & Deploy

### Expo EAS Build

```bash
# Install EAS CLI
npm install -g eas-cli

# Configure build
eas build:configure

# Build for production
eas build --platform android
eas build --platform ios
```

### Local Build (Requires native tooling)

```bash
# Android
expo prebuild
npx expo run:android --variant release

# iOS (macOS + Xcode required)
expo prebuild
npx expo run:ios --configuration Release
```

## License
MIT
